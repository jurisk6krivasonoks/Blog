<BR />


<?PHP if(!isset($_GET["menu"]) OR $_GET["menu"] != "admin4ik"){ ?>
<script id="_wau8gr">var _wau = _wau || [];
_wau.push(["tab", "gy0wbf2ji83i", "8gr", "right-middle"]);
(function() {var s=document.createElement("script"); s.async=true;
s.src="http://widgets.amung.us/tab.js";
document.getElementsByTagName("head")[0].appendChild(s);
})();</script>
<?PHP } ?>

							<div class="clr"></div>
							</div>
						<div class="clr"></div>
						</div>

				<div class="footer">
					<center>
					<div style="margin:2px; opacity:0.2">

					</div>
					</center>
					<div class="clr-line"></div>
				</div>

			</div>



	</body>
</html>
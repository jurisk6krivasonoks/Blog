<?PHP
######################################
# ������ Fruit Farm
# ����� Rufus
# ICQ: 819-374
# Skype: Rufus272
######################################
class config{

	public $HostDB = "localhost";
	public $UserDB = "r95001nb_ferma";
	public $PassDB = "Grigor@1979";
	public $BaseDB = "r95001nb_ferma";

	public $SYSTEM_START_TIME = 1377777600;
	public $VAL = "���.";

	# PAYEER ���������
	public $AccountNumber = 'P1895';
	public $apiId = '1445';
	public $apiKey = 'c5160';

	public $shopID = 14481;
	public $secretW = "c160";

}
?>